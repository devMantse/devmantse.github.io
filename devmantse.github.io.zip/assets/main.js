

var name = 4;



                        /* Hello my name is */
                        #developer name{

                        }